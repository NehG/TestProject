﻿using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Data.Entity;

namespace ElevatorManagementSystem.Models
{
    public class DBModelContext : DbContext
    {
        public DBModelContext() : base("ElevatorManagementSystemNew")
        {
        }

        public virtual DbSet<BuildingModel> Buildings { get; set; }
        public virtual DbSet<ElevatorModel> Elevators { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BuildingModel>()
                .HasMany(e => e.Elevators)
                .WithRequired(e => e.Building)
                .WillCascadeOnDelete(true);

            modelBuilder.Entity<ElevatorModel>()
                .Property(e => e.ElevatorLimitWeight)
                .HasPrecision(18, 0);
        }
    }
}
