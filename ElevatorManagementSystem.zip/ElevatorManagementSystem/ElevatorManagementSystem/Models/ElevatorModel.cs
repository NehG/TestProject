﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ElevatorManagementSystem.Models
{
    [Table("Elevator")]
    public partial class ElevatorModel
    {
        [Key]
        public Guid ElevatorNumber { get; set; }

        public int ElevatorLimitPeople { get; set; }

        public decimal ElevatorLimitWeight { get; set; }

        public Guid BuildingId { get; set; }

        public virtual BuildingModel Building { get; set; }
    }
}
