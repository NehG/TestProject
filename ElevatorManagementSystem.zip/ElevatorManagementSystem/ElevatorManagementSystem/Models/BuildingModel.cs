﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ElevatorManagementSystem.Models
{ 
    [Table("Building")]
    public partial class BuildingModel
    {
        public BuildingModel()
        {
            Elevators = new HashSet<ElevatorModel>();
        }

        [Key]
        public Guid BuildingId { get; set; }

        [Required]
        public string BuildingName { get; set; }

        public int BuildingLimitElevatorNo { get; set; }

        public virtual ICollection<ElevatorModel> Elevators { get; set; }
    }
}
