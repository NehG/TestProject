﻿namespace ElevatorManagementSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Building",
                c => new
                    {
                        BuildingId = c.Guid(nullable: false),
                        BuildingName = c.String(nullable: false),
                        BuildingLimitElevatorNo = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.BuildingId);
            
            CreateTable(
                "dbo.Elevator",
                c => new
                    {
                        ElevatorNumber = c.Guid(nullable: false),
                        ElevatorLimitPeople = c.Int(nullable: false),
                        ElevatorLimitWeight = c.Decimal(nullable: false, precision: 18, scale: 0),
                        BuildingId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ElevatorNumber)
                .ForeignKey("dbo.Building", t => t.BuildingId)
                .Index(t => t.BuildingId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Elevator", "BuildingId", "dbo.Building");
            DropIndex("dbo.Elevator", new[] { "BuildingId" });
            DropTable("dbo.Elevator");
            DropTable("dbo.Building");
        }
    }
}
