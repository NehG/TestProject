﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ElevatorManagementSystem.Data;
using ElevatorManagementSystem.Models;

namespace ElevatorManagementSystem.Controllers
{
    public class ElevatorController : Controller
    {
        private readonly ElevatorManagementSystemContext _context;

        public ElevatorController(ElevatorManagementSystemContext context)
        {
            _context = context;
        }

        // GET: Elevator
        public async Task<IActionResult> Index()
        {
            var elevatorManagementSystemContext = _context.ElevatorModel.Include(e => e.Building);
            return View(await elevatorManagementSystemContext.ToListAsync());
        }

        // GET: Elevator/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var elevatorModel = await _context.ElevatorModel
                .Include(e => e.Building)
                .FirstOrDefaultAsync(m => m.ElevatorNumber == id);
            if (elevatorModel == null)
            {
                return NotFound();
            }

            return View(elevatorModel);
        }

        // GET: Elevator/Create
        public IActionResult Create()
        {
            ViewData["BuildingId"] = new SelectList(_context.BuildingModel, "BuildingId", "BuildingName");
            ElevatorModel elevator = new ElevatorModel();
            elevator.ElevatorNumber = System.Guid.NewGuid();
            return View(elevator);
        }

        // POST: Elevator/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ElevatorNumber,ElevatorLimitPeople,ElevatorLimitWeight,BuildingId")] ElevatorModel elevatorModel)
        {
            //int count = _context.ElevatorModel.Where(e => e.BuildingId == elevatorModel.BuildingId).Count();
            //var maxCount = _context.BuildingModel.Where(b => b.BuildingId == elevatorModel.BuildingId).Select(b => b.BuildingLimitElevatorNo);

            //if (count < maxCount)
            try{
                if (ModelState.IsValid)
                {
                    _context.Add(elevatorModel);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                ViewData["BuildingId"] = new SelectList(_context.BuildingModel, "BuildingId", "BuildingName", elevatorModel.BuildingId);
            }
            //else
            //{
              //  ViewBag.Message = "Error Max Elevator Count Reached for " + elevatorModel.BuildingId;
                //return View();
            //}
            catch(Exception e)
            {
                throw e;
            }
            return View(elevatorModel);
        }

        // GET: Elevator/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var elevatorModel = await _context.ElevatorModel.FindAsync(id);
            if (elevatorModel == null)
            {
                return NotFound();
            }
            ViewData["BuildingId"] = new SelectList(_context.BuildingModel, "BuildingId", "BuildingName", elevatorModel.BuildingId);
            return View(elevatorModel);
        }

        // POST: Elevator/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("ElevatorNumber,ElevatorLimitPeople,ElevatorLimitWeight,BuildingId")] ElevatorModel elevatorModel)
        {
            if (id != elevatorModel.ElevatorNumber)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(elevatorModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ElevatorModelExists(elevatorModel.ElevatorNumber))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BuildingId"] = new SelectList(_context.BuildingModel, "BuildingId", "BuildingName", elevatorModel.BuildingId);
            return View(elevatorModel);
        }

        // GET: Elevator/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var elevatorModel = await _context.ElevatorModel
                .Include(e => e.Building)
                .FirstOrDefaultAsync(m => m.ElevatorNumber == id);
            if (elevatorModel == null)
            {
                return NotFound();
            }

            return View(elevatorModel);
        }

        // POST: Elevator/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var elevatorModel = await _context.ElevatorModel.FindAsync(id);
            _context.ElevatorModel.Remove(elevatorModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ElevatorModelExists(Guid id)
        {
            return _context.ElevatorModel.Any(e => e.ElevatorNumber == id);
        }
    }
}
