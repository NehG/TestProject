﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ElevatorManagementSystem.Data;
using ElevatorManagementSystem.Models;

namespace ElevatorManagementSystem.Controllers
{
    public class BuildingController : Controller
    {
        private readonly ElevatorManagementSystemContext _context;

        public BuildingController(ElevatorManagementSystemContext context)
        {
            _context = context;
        }

        // GET: Building
        public async Task<IActionResult> Index()
        {
            return View(await _context.BuildingModel.ToListAsync());
        }

        // GET: Building/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var buildingModel = await _context.BuildingModel
                .FirstOrDefaultAsync(m => m.BuildingId == id);
            if (buildingModel == null)
            {
                return NotFound();
            }

            return View(buildingModel);
        }

        // GET: Building/Create
        public IActionResult Create()
        {
            BuildingModel building = new BuildingModel();
            building.BuildingId = System.Guid.NewGuid();
            return View(building);
        }

        // POST: Building/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BuildingId,BuildingName,BuildingLimitElevatorNo")] BuildingModel buildingModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(buildingModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(buildingModel);
        }

        // GET: Building/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var buildingModel = await _context.BuildingModel.FindAsync(id);
            if (buildingModel == null)
            {
                return NotFound();
            }
            return View(buildingModel);
        }

        // POST: Building/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("BuildingId,BuildingName,BuildingLimitElevatorNo")] BuildingModel buildingModel)
        {
            if (id != buildingModel.BuildingId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(buildingModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BuildingModelExists(buildingModel.BuildingId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(buildingModel);
        }

        // GET: Building/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var buildingModel = await _context.BuildingModel
                .FirstOrDefaultAsync(m => m.BuildingId == id);
            if (buildingModel == null)
            {
                return NotFound();
            }

            return View(buildingModel);
        }

        // POST: Building/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var buildingModel = await _context.BuildingModel.FindAsync(id);
            _context.BuildingModel.Remove(buildingModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BuildingModelExists(Guid id)
        {
            return _context.BuildingModel.Any(e => e.BuildingId == id);
        }
    }
}
