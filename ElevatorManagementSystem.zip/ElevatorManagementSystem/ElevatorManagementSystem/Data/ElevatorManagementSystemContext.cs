﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ElevatorManagementSystem.Models;

namespace ElevatorManagementSystem.Data
{
    public class ElevatorManagementSystemContext : DbContext
    {
        public ElevatorManagementSystemContext (DbContextOptions<ElevatorManagementSystemContext> options)
            : base(options)
        {
        }

        public DbSet<ElevatorManagementSystem.Models.BuildingModel> BuildingModel { get; set; }

        public DbSet<ElevatorManagementSystem.Models.ElevatorModel> ElevatorModel { get; set; }
    }
}
